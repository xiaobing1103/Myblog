public class Main {
    static int shipping(int subtotal) {
        if (subtotal < 0) {
            throw new IllegalArgumentException("subtotal must not be negative");
        }
        return subtotal >= 10000 ? 0 : 1000;
    }

    static void changeNumber(int number) {
        number = 99;
    }

    static void changeArray(int[] values) {
        values[0] = 99;
        values = new int[] {7};
    }

    public static void main(String[] args) {
        int number = 1;
        int[] values = {1};
        changeNumber(number);
        changeArray(values);
        System.out.println(shipping(9999));
        System.out.println(shipping(10000));
        System.out.println(number);
        System.out.println(values[0]);
    }
}
