# 第 05 课：方法与参数传递

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
1000
0
1
99
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/05-methods/
