# 第 03 课：运算、比较与金额

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
2
2.5
20640
true
false
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/03-operators/
