public class Main {
    public static void main(String[] args) {
        long unitPrice = 12900L;
        int quantity = 2;
        int discountPercent = 80;
        long discounted = unitPrice * discountPercent / 100;
        long total = discounted * quantity;
        String coupon = null;
        boolean validCoupon = coupon != null && !coupon.isBlank();
        System.out.println(5 / 2);
        System.out.println(5 / 2.0);
        System.out.println(total);
        System.out.println(total >= 20000 && quantity > 0);
        System.out.println(validCoupon);
    }
}
