# 第 10 课：集合、泛型与相等性

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
2
[Java, SQL]
SQL
{java=2, sql=1}
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/10-collections/
