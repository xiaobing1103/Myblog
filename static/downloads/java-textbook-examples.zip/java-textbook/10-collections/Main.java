import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main {
    record Task(long id, String title) {}

    public static void main(String[] args) {
        List<Task> tasks = new ArrayList<>();
        tasks.add(new Task(1, "Java"));
        tasks.add(new Task(2, "SQL"));
        Set<String> tags = new LinkedHashSet<>(List.of("Java", "SQL", "Java"));
        Map<Long, Task> byId = new LinkedHashMap<>();
        for (Task task : tasks) byId.put(task.id(), task);
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (String word : List.of("java", "sql", "java")) {
            counts.merge(word, 1, Integer::sum);
        }
        System.out.println(tasks.size());
        System.out.println(tags);
        System.out.println(byId.get(2L).title());
        System.out.println(counts);
    }
}
