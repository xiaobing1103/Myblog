# 第 08 课：接口、多态与组合

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
Notice: Completed Java
Completed SQL
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/08-interfaces/
