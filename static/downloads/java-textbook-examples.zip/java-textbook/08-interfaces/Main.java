public class Main {
    interface Notifier {
        void send(String message);
    }

    static class ConsoleNotifier implements Notifier {
        public void send(String message) {
            System.out.println("Notice: " + message);
        }
    }

    static class RecordingNotifier implements Notifier {
        private String lastMessage;
        public void send(String message) { lastMessage = message; }
        String lastMessage() { return lastMessage; }
    }

    static class TaskService {
        private final Notifier notifier;
        TaskService(Notifier notifier) { this.notifier = notifier; }
        void finish(String title) { notifier.send("Completed " + title); }
    }

    public static void main(String[] args) {
        TaskService consoleService = new TaskService(new ConsoleNotifier());
        consoleService.finish("Java");
        RecordingNotifier recorder = new RecordingNotifier();
        TaskService testService = new TaskService(recorder);
        testService.finish("SQL");
        System.out.println(recorder.lastMessage());
    }
}
