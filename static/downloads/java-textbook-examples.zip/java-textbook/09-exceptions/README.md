# 第 09 课：异常、堆栈与调试

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
Accepted 2
Not an integer
quantity must be positive
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/09-exceptions/
