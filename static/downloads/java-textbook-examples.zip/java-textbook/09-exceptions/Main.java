public class Main {
    static int parseQuantity(String text) {
        int value = Integer.parseInt(text);
        if (value <= 0) {
            throw new IllegalArgumentException("quantity must be positive");
        }
        return value;
    }

    static void show(String input) {
        try {
            int quantity = parseQuantity(input);
            System.out.println("Accepted " + quantity);
        } catch (NumberFormatException e) {
            System.out.println("Not an integer");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        show("2");
        show("abc");
        show("0");
    }
}
