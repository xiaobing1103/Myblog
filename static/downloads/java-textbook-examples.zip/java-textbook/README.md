# Java 后端开发分步教材示例

使用 JDK 21。各课的 Main.java 独立保存，请进入对应目录再运行，不要把所有 Main 类一起编译。

01—14 课为单文件示例；第 12 课创建临时文件并清理，第 14 课短暂启动本地随机端口 HTTP 服务并自动停止。后四课请下载 java-todo-api.zip，结合教材操作 Maven 工程。

目录：https://xiaobing1103.github.io/Myblog/docs/java/textbook/
