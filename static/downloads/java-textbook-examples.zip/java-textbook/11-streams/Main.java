import java.util.List;
import java.util.Optional;

public class Main {
    record Order(long id, int cents, boolean paid) {}

    public static void main(String[] args) {
        List<Order> orders = List.of(
            new Order(1, 300, true),
            new Order(2, 999, false),
            new Order(3, 400, true)
        );
        List<Long> paidIds = orders.stream()
            .filter(Order::paid)
            .map(Order::id)
            .toList();
        int total = orders.stream()
            .filter(Order::paid)
            .mapToInt(Order::cents)
            .sum();
        Optional<Order> missing = orders.stream()
            .filter(order -> order.id() == 99)
            .findFirst();
        System.out.println(paidIds);
        System.out.println(total);
        System.out.println(missing.map(order -> "Order " + order.id()).orElse("Not found"));
    }
}
