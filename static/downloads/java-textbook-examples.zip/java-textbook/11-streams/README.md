# 第 11 课：Lambda、Stream 与 Optional

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
[1, 3]
700
Not found
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/11-streams/
