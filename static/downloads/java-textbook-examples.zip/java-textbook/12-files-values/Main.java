import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) throws Exception {
        BigDecimal price = new BigDecimal("19.90");
        BigDecimal discounted = price.multiply(new BigDecimal("0.85"))
            .setScale(2, RoundingMode.HALF_UP);
        LocalDate date = LocalDate.of(2026, 10, 28);
        String report = date + " | " + discounted.toPlainString();
        Path file = Files.createTempFile("java-report-", ".txt");
        try {
            Files.writeString(file, report, StandardCharsets.UTF_8);
            String restored = Files.readString(file, StandardCharsets.UTF_8);
            System.out.println(restored);
            System.out.println(date.plusDays(1));
            System.out.println(new BigDecimal("1.0").compareTo(new BigDecimal("1.00")) == 0);
        } finally {
            Files.deleteIfExists(file);
        }
    }
}
