# 第 12 课：文件、日期与精确金额

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
2026-10-28 | 16.92
2026-10-29
true
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/12-files-values/
