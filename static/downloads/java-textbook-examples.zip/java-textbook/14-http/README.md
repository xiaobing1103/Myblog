# 第 14 课：从一次真实 HTTP 请求理解后端

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
200
application/json; charset=utf-8
{"status":"UP"}
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/14-http/
