public class Main {
    public static void main(String[] args) {
        int[] prices = {3000, 4500, 2500};
        int subtotal = 0;
        for (int price : prices) {
            if (price < 0) {
                throw new IllegalArgumentException("price must not be negative");
            }
            subtotal += price;
        }
        int shipping;
        if (subtotal >= 10000) {
            shipping = 0;
        } else {
            shipping = 1000;
        }
        String status = "PAID";
        String label = switch (status) {
            case "PAID" -> "Ready to ship";
            case "NEW" -> "Awaiting payment";
            default -> "Unknown status";
        };
        System.out.println(subtotal);
        System.out.println(shipping);
        System.out.println(label);
    }
}
