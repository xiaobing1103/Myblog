# 第 04 课：分支、循环与边界

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
10000
0
Ready to ship
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/04-control-flow/
