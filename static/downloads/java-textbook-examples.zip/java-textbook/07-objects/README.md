# 第 07 课：类、对象与封装

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
1: Build an API / true
true
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/07-objects/
