public class Main {
    static final class Task {
        private final long id;
        private String title;
        private boolean done;

        Task(long id, String title) {
            if (id <= 0) throw new IllegalArgumentException("id must be positive");
            this.id = id;
            rename(title);
        }

        void rename(String title) {
            if (title == null || title.isBlank()) {
                throw new IllegalArgumentException("title must not be blank");
            }
            this.title = title.strip();
        }

        void complete() { this.done = true; }
        String summary() { return id + ": " + title + " / " + done; }
    }

    public static void main(String[] args) {
        Task task = new Task(1, " Learn Java ");
        Task alias = task;
        task.complete();
        alias.rename("Build an API");
        System.out.println(task.summary());
        System.out.println(task == alias);
    }
}
