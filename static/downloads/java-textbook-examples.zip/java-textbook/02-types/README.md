# 第 02 课：类型、变量与空值

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
Java course x 2
25800
false
true
No note
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/02-types/
