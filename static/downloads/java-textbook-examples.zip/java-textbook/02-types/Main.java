public class Main {
    public static void main(String[] args) {
        String title = "Java course";
        int quantity = 2;
        long priceInCents = 12900L;
        boolean paid = false;
        var label = title + " x " + quantity;
        final int maxQuantity = 5;
        String note = null;
        System.out.println(label);
        System.out.println(priceInCents * quantity);
        System.out.println(paid);
        System.out.println(quantity <= maxQuantity);
        System.out.println(note == null ? "No note" : note);
    }
}
