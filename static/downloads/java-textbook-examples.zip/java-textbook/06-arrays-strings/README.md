# 第 06 课：数组、字符串与输入

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
3
Java | SQL | HTTP
false
true
43
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/06-arrays-strings/
