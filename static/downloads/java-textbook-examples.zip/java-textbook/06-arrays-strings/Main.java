public class Main {
    public static void main(String[] args) {
        String input = " Java , SQL , HTTP ";
        String[] pieces = input.split(",");
        StringBuilder summary = new StringBuilder();
        for (int i = 0; i < pieces.length; i++) {
            String title = pieces[i].strip();
            if (title.isBlank()) {
                throw new IllegalArgumentException("empty title");
            }
            if (i > 0) summary.append(" | ");
            summary.append(title);
        }
        String left = new String("Java");
        String right = new String("Java");
        System.out.println(pieces.length);
        System.out.println(summary);
        System.out.println(left == right);
        System.out.println(left.equals(right));
        System.out.println(Integer.parseInt("42") + 1);
    }
}
