public class Main {
    public static void main(String[] args) {
        String learner = "Frontend developer";
        int lesson = 1;
        System.out.println("Hello, " + learner);
        System.out.println("Lesson " + lesson);
    }
}
