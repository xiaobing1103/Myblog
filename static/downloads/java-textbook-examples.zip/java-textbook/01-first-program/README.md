# 第 01 课：环境与第一个程序

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
Hello, Frontend developer
Lesson 1
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/01-first-program/
