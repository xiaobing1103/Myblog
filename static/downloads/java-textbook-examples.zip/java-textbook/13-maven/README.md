# 第 13 课：Maven、包与工程结构

在本目录执行：

```sh
java Main.java
```

预期输出：

```text
Learner: Java
Mode: local
```

完整讲解：https://xiaobing1103.github.io/Myblog/docs/java/textbook/13-maven/
