public class Main {
    public static void main(String[] args) {
        String learner = args.length > 0 ? args[0] : "Java";
        String mode = System.getProperty("study.mode", "local");
        System.out.println("Learner: " + learner);
        System.out.println("Mode: " + mode);
    }
}
